/*     
Aufgabe:(Endabagbe -  Canvas - TIAABF) 
Name: Daniel Mainberger
Matrikel: (260566)
Datum: (24.07.2019) 
*/

/*Superklasse für bewegte Objekte*/ 

namespace UnderTheSea {

    export class Moving {
        size: number;
        x: number;
        y: number;
        dx: number;
        dy: number;

        constructor() {

        }
        update() { };
    }
}
