/*
Aufgabe:(Endabagbe -  Canvas - TIAABF)
Name: Daniel Mainberger
Matrikel: (260566)
Datum: (24.07.2019)
*/
/*Superklasse für bewegte Objekte*/
var UnderTheSea;
(function (UnderTheSea) {
    class Moving {
        constructor() {
        }
        update() { }
        ;
    }
    UnderTheSea.Moving = Moving;
})(UnderTheSea || (UnderTheSea = {}));
//# sourceMappingURL=Moving.js.map