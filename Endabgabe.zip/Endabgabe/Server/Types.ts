/*     
Aufgabe:(Endabagbe -  Canvas - TIAABF) 
Name: Daniel Mainberger
Matrikel: (260566)
Datum: (24.07.2019) 
*/

interface Highscores {
    [key: string]: string;
}

interface GameData {
    playername: string;
    score: number;
}